#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>
#include<sys/wait.h>
#include<sys/types.h>
#include <fcntl.h>
#include<pwd.h>
#define true 1



void sig_handler(int signo)
{
	signal(SIGINT,sig_handler);
}
void dividleft(char**lleft,char*left)
{
	int i=0;
	char*ptr=strtok(left," ");
	while(ptr!=NULL)
	{
		if(ptr[strlen(ptr)-1]=='\n')
		{
			ptr[strlen(ptr)-1]=0;
		}
		strcpy(lleft[i],ptr);
		i++;
		ptr=strtok(NULL," ");
	}
	lleft[i]=NULL;
}
void dividright(char**rright,char*right)
{
	int i=0;
	char*ptr=strtok(right," ");
	while(ptr!=NULL)
	{
		if(ptr[strlen(ptr)-1]=='\n')
		{
			ptr[strlen(ptr)-1]=0;
		}
		strcpy(rright[i],ptr);
		i++;
		ptr=strtok(NULL," ");
	}
	rright[i]=NULL;
}
void dividbrackets(char*fold,char**lleft,char*taken,int bracketsIndex,int brackets)
{
	int i=0,j=0;
	char*ptr=strtok(taken," ");
	while(ptr!=NULL)
	{
		if(ptr[strlen(ptr)-1]=='\n')
		{
			ptr[strlen(ptr)-1]=0;
		}
		if(i==bracketsIndex)
		{
			ptr=strtok(NULL," ");
		}
		if(j<2&&bracketsIndex>5)
		{
			j++;
			strcpy(lleft[i],ptr);
		}
		if(j<1&&bracketsIndex < 5)
		{
			j++;
			strcpy(lleft[0],ptr);
		}
		else
		{
			strcpy(fold,ptr);
		}
		i++;
		ptr=strtok(NULL," ");
	}	
	if(bracketsIndex<5)
		lleft[1]=NULL;
	if(bracketsIndex>5)
		lleft[2]=NULL;
}
void BRAKTES(char*taken,char**lleft,int brackets,int bracketsIndex)
{
	char fold[15];
	dividbrackets(fold,lleft,taken,bracketsIndex,brackets);
	pid_t pid=fork();
	if(pid==0)
	{
		if(brackets==1)
		{
			int fd = open(fold, O_WRONLY|O_CREAT|O_TRUNC, S_IRWXU);
			dup2(fd, STDOUT_FILENO);
			close(fd);
			execvp(lleft[0],lleft);
			exit(-1);
		}
		if(brackets==2)
		{
			int fd=open(fold,O_WRONLY | O_CREAT | O_APPEND , S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH);
			dup2(fd, STDOUT_FILENO);
			close(fd);
			execvp(lleft[0],lleft);
			exit(-1);
		}
	}
	else
	{
		wait(NULL);
	}
}
void pipeMethod(char*taken)
{
	char**lleft=(char**)malloc(3*sizeof(char*));
	int s;
	for(s=0;s<3;s++)
	{
		lleft[s]=(char*)malloc(3*sizeof(char));
	}
	char**rright=(char**)malloc(3*sizeof(char*));
	for(s=0;s<3;s++)
	{
		rright[s]=(char*)malloc(3*sizeof(char));
	}
	int pipeindex=0,i,j=0;
	char left[10],right[10];
	for(i=0;i<strlen(taken)+1;i++)
	{
		if(taken[i]=='|')
		{
			pipeindex=i;
		}
	}
	for(i=0;i<strlen(taken)+1;i++)
	{
		if(i<pipeindex-1)
		{
			left[i]=taken[i];
		}
		if(i>pipeindex+1)
		{
			right[j]=taken[i];
			j++;
		}
	}
	dividleft(lleft,left);
	dividright(rright,right);
	int pipefd[2];
	int status;
	pid_t leftpid,rightpid;
	pipe(pipefd);
	if((leftpid=fork())==0)
	{
		dup2(pipefd[1],STDOUT_FILENO);
		close(pipefd[0]);
		execvp(lleft[0],lleft);
	}
	else if((rightpid=fork())==0)
	{
		dup2(pipefd[0],STDIN_FILENO);
		close(pipefd[1]);
		execvp(rright[0],rright);
	}
	else
	{
		close(pipefd[0]);
		close(pipefd[1]);
		wait(&status);
		wait(&status);
		for(s=0;s<3;s++)
		{
			free(lleft[s]);
		}
		free(lleft);
		for(s=0;s<3;s++)
		{
			free(rright[s]);
		}
		free(rright);
	}
}
void DIVIDWORDS(char**array,char*taken)
{
	int i=0;
	char*ptr=strtok(taken," ");
	while(ptr!=NULL)
	{
		if(ptr[strlen(ptr)-1]=='\n')
		{
			ptr[strlen(ptr)-1]=0;
		}
		strcpy(array[i],ptr);
		i++;
		ptr=strtok(NULL," ");
	}
	array[i]=NULL;
}
void NOPIPENOANDPERCENT(char*taken,int*numOfCmd,int*cmdLength)
{
	int i;
	char**array=(char**)malloc(sizeof(char*)*510);
	if(array==NULL)
	{
		printf("ERR\n");
		exit(1);
	}
	for(i=0;i<510;i++)
	{
		array[i]=(char*)malloc(sizeof(char)*20);
	}
	DIVIDWORDS(array,taken);
	if(strcmp(array[0],"done")==0)
	{
		printf("numOfCmd=%d\n",(*numOfCmd));
		printf("cmdLength=%d\n",(*cmdLength));
		printf("bye!\n");
		free(array[0]);
		exit(0);
	}
	if(strcmp(array[0],"cd")==0)
 	{
		(*numOfCmd)++;
		(*cmdLength)+=2;
		chdir(array[1]);
 	}
	pid_t pid=fork();
	if(pid==-1)
	{
		printf("ERR\n");
		exit(1);
	}
	if(pid==0)
	{
		execvp(array[0],array);
		exit(1);
	}
	else
	{
		int status;
		wait(&status);
		if(WEXITSTATUS(status)!=0)
		{
			for(i=0;i<510;i++)
			{
				free(array[i]);
			}
			free(array);
		}
		if(WEXITSTATUS(status)==0)
		{
			if(strcmp(array[0],"cd")==0)
			{
				exit(0);
			}
			(*numOfCmd)++;
			for(i=0;i<20;i++)
			{
				if(array[0][i]=='\0')
					break;
				(*cmdLength)++;
			}
			for(i=0;i<510;i++)
			{
				free(array[i]);
			}
			free(array);
		}
	}
}
int main(int argc, char *argv[])
{
	int i,numOfCmd=0,cmdLength=0,needToMakePipe=0,ampercent=0,brackets=0,bracketsIndex=0,j=0;
	char cwd[50];
	uid_t uid=0;
	struct passwd *pwd;
	while(true)
	{
		pwd = getpwuid(uid);
		getcwd(cwd, 50);
		char taken[510];
		printf("%s@%s ~$ ",pwd->pw_name,cwd);
		signal(SIGINT,sig_handler);
		fgets(taken,510,stdin);
		for(i=0;i<strlen(taken)+1;i++)
		{
			if(taken[i]=='|')
			{
				needToMakePipe=1;
			}
			if(taken[i]=='>')
			{
				brackets=1;
				bracketsIndex=i;
				if(taken[i-1]=='>')
				{
					brackets=2;
				}
			}
		}
		if(needToMakePipe==1)
		{
			pipeMethod(taken);
		}
		if(brackets>0)
		{
			char**lleft=(char**)malloc(3*sizeof(char*));
			int s;
			for(s=0;s<3;s++)
			{
				lleft[s]=(char*)malloc(3*sizeof(char));
			}
			BRAKTES(taken,lleft,brackets,bracketsIndex);
			//printf("back to main\n");
			for(s=0;s<3;s++)
			{
				free(lleft[s]);
			}
			free(lleft);
			brackets=0;
			continue;
		}
		brackets=0;
		if(needToMakePipe==0&&ampercent==0)
		{
			NOPIPENOANDPERCENT(taken,&numOfCmd,&cmdLength);
		}
	}
	return 0;
}