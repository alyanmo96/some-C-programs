#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>
#include<sys/wait.h>
#include<sys/types.h>
#include <fcntl.h>
#include<sys/ipc.h>
#include<sys/shm.h>



void merge(int arr[],int l,int m,int h)
{
  int arr1[10],arr2[10];  // Two temporary arrays to
  int n1,n2,i,j,k;
  n1=m-l+1;
  n2=h-m;

  for(i=0;i<n1;i++)
    arr1[i]=arr[l+i];
  for(j=0;j<n2;j++)
    arr2[j]=arr[m+j+1];

  arr1[i]=9999;  // To mark the end of each temporary array
  arr2[j]=9999;

  i=0;j=0;
  for(k=l;k<=h;k++)  //process of combining two sorted arrays
  {
    if(arr1[i]<=arr2[j])
      arr[k]=arr1[i++];
    else
      arr[k]=arr2[j++];
  }
}

void merge_sort(int arr[],int low,int high)
{
  int mid;
  if(low<high)
  {
    mid=(low+high)/2;
   // Divide and Conquer
    merge_sort(arr,low,mid);
    merge_sort(arr,mid+1,high);
   // Combine
    merge(arr,low,mid,high);
  }
}
int main()
{
 	int AllLength,i,Degree;
	FILE *f=fopen("input.txt","r");
	fscanf(f,"%d",&AllLength);
  printf("Amount of numbers that sort : %d\n",AllLength);
	fscanf(f,"%d",&Degree);
  printf("Degree of parallelism : %d\n",Degree);
	int part=(AllLength/Degree);
	char buffer[part],rbuf[part]; 
	int*arr=(int*)malloc(AllLength*sizeof(int));
	for(i=0;i<AllLength;i++)
	{
     if(i<(AllLength-1))
		  {
        fscanf(f,"%d,",&arr[i]);
		  }
		  else
		  {
			  fscanf(f,"%d",&arr[i]);
		  }
	}
  printf("before Sorted the array: ");  // print sorted array
	  for(i=0;i<AllLength;i++)
	  {
		  if(i<(AllLength-1))
		  {
			  printf("%d , ",arr[i]);
		  }
		  else
		  {
			  printf("%d \n ",arr[i]);
		  }
	  }
  
  
	int start=0,end=(AllLength/Degree),k=0,next=(AllLength/Degree),count=Degree,j=0;
	while(j<count)
	{
		pid_t pid1=fork();
		if(pid1==0)
		{
			printf("create a process %d\n",getpid());
			merge_sort(arr,start,end-1);  // sort one group of the array 
			exit(0);
		}
		else
		{
			wait(NULL);
		}
		start=end;
		end+=next;
		pid_t pid2=fork();
		if(pid2==0)
		{
			printf("create a process %d\n",getpid());
			merge_sort(arr,start,end-1);  // sort one group of the array
			exit(0);
		}
		else
		{
			wait(NULL);
		}
		merge_sort(arr,k,end-1);  // sort the both group the each one is already sorted
		k=end;
		start=end;end+=next;
		j++;
		if(j==(Degree/2))
		{
			break;
		}
	}
  merge_sort(arr,0,AllLength-1);  // sort the array
  printf("after Sorted the array:\n");  // print sorted array
  for(i=0;i<AllLength;i++)
  {
	  if(i<(AllLength-1))
	  {
		  printf("%d , ",arr[i]);
	  }
	  else
	  {
		  printf("%d \n ",arr[i]);
	  }
  }
  return 0;
}