#include "mem_sim.h"
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include<sys/stat.h>
#include<fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <unistd.h>
#include <assert.h>
#define PAGE_SIZE 5
#define NUM_OF_PAGES 25
#define MEMORY_SIZE 20


static int FrameIndex=0,FrameLastIndex=(MEMORY_SIZE/PAGE_SIZE),DeleteFrame=0,codeSize;
static int array[MEMORY_SIZE/PAGE_SIZE];
/************************************************	ARRAY METHODS	***************************************************************/
void insertInArray(int array[],int frame ,int page )
{
	if(frame<0||frame>=FrameLastIndex)
	{
		perror("invalid frame!");
		return ;
	}
	array[FrameIndex]=page;
	FrameIndex++;
}
void deleteInArray(int array[])
{
	FrameIndex=0;
	array[DeleteFrame]=0;
	DeleteFrame++;
	if(DeleteFrame==FrameLastIndex)
	{
		DeleteFrame=0;
	}
}
/************************************************	INIT	***********************************************************************/
struct sim_database * init_system(char exe_file_name[],char swap_file_name[],int text_size,int data_bss_size,int heap_stack_size)
{
	if(exe_file_name==NULL||swap_file_name==NULL)
	{
		fprintf(stderr,"invalid file name\n");
		return NULL;
	}
	int program_fd=open(exe_file_name,O_RDONLY,0);
	struct sim_database * sim_db=(struct sim_database*)malloc(sizeof(struct sim_database));
	sim_db->program_fd=program_fd;	 
	sim_db->swapfile_fd=open(swap_file_name,O_TRUNC|O_CREAT|O_RDWR,S_IRWXU|S_IRWXG|S_IRWXO);
	sim_db->data_bss_size=data_bss_size;
	sim_db->heap_stack_size=heap_stack_size;
	sim_db->text_size=text_size;
	codeSize=(text_size/PAGE_SIZE);
	int i;
	for(i=0;i<MEMORY_SIZE;i++)
	{
		sim_db->main_memory[i]=0;
	}
	for(i=0;i< NUM_OF_PAGES;i++)
	{
		sim_db->page_table[i].V=0;
		sim_db->page_table[i].frame=-1;
		sim_db->page_table[i].D=0;
		sim_db->page_table[i].P=0;
		if(i<(text_size/PAGE_SIZE))
		{
			sim_db->page_table[i].P=0;
		}
		else
		{
			sim_db->page_table[i].P=1;
		}
	}
	return sim_db;
}
/************************************************	LOAD	***********************************************************************/
char load (struct sim_database * mem_sim ,int address)
{
	if(address<0||address>=(NUM_OF_PAGES*PAGE_SIZE))
	{
		perror("invalid address!");
		return '\0';
	}
	int page=(address/PAGE_SIZE);
	int offset=(address%PAGE_SIZE);
	if(mem_sim->page_table[page].V==1)
	{
		int phsical_address=((mem_sim->page_table[page].frame*PAGE_SIZE)+offset);
		return mem_sim->main_memory[phsical_address];
	}
	else//V==0
	{
		if(mem_sim->page_table[page].P==1)// go to check D
		{
			if(mem_sim->page_table[page].D==1)//swap file
			{
				int fd=mem_sim->swapfile_fd;
				lseek(fd,mem_sim->page_table[page].frame,SEEK_SET); 
				char buffer[PAGE_SIZE];//read the page into buffer
				int i,m;
				for(i=0,m=mem_sim->page_table[page].frame*4;i<PAGE_SIZE;i++,m++)
				{
					buffer[i]=mem_sim->main_memory[m];
				}
				if(read(fd,buffer,PAGE_SIZE)!=PAGE_SIZE)
				{
					perror("read error!");
					return -1;
				}
				int begin_index=0;
				if(FrameIndex<FrameLastIndex)//memory is not full
				{
					begin_index=FrameIndex*4;
					int i,m;
					for(i=0,m=begin_index;i<PAGE_SIZE;i++,m++)
					{
						mem_sim->main_memory[m]=buffer[i];
					}
					insertInArray(array,FrameIndex,page);
					mem_sim->page_table[page].frame=FrameIndex;
					mem_sim->page_table[page].V=1;
					mem_sim->page_table[page].P=0;
				}
				else//if the memory is full
				{
					deleteInArray(array);
					int frame=FrameIndex; 
					char vbuffer[PAGE_SIZE];
					int i,m;
					for(i=0,m=FrameIndex*4;i<PAGE_SIZE;i++,m++)
					{
						vbuffer[i]=mem_sim->main_memory[m];
					}					//rewrite into swap
					lseek(fd,FrameIndex*4,SEEK_SET); 
					if(write(fd,vbuffer,PAGE_SIZE)<PAGE_SIZE)
					{
						perror("write error!");
						return -1;
					}
					mem_sim->page_table[FrameIndex].P=1;
					mem_sim->page_table[FrameIndex].V =0;
					begin_index=FrameIndex*4;
					for(m=begin_index,i=0;i<4;i++,m++)
					{
						mem_sim->main_memory[m]=buffer[i];
					}
					insertInArray(array,frame,page);
					mem_sim->page_table[page].frame=frame;
					mem_sim->page_table[page].V=1;
					mem_sim->page_table[page].P=0;	
				}
			}
			else//D=0
			{
				if(codeSize>0)
				{
					int fd=mem_sim->program_fd;
					lseek(fd,FrameIndex*4,SEEK_SET);
					char buffer[PAGE_SIZE];
					if(read(fd,buffer,PAGE_SIZE)!=PAGE_SIZE)
					{
						perror("read error!");
						return -1;
					}
					int begin_index=0;
					if(FrameIndex<FrameLastIndex)//memory is not full
					{
						begin_index=FrameIndex*4;
						int i,m;
						for(i=0,m=begin_index;i<PAGE_SIZE;i++,m++)
						{
							mem_sim->main_memory[m]=buffer[i];
						}
						insertInArray(array,FrameIndex,page);
						mem_sim->page_table[page].frame=FrameIndex;
						mem_sim->page_table[page].V=1;
						mem_sim->page_table[page].P=0;
					}
					else//if the memory is full
					{
						deleteInArray(array);
						int fram=FrameIndex; 
						char vbuffer[PAGE_SIZE];
						int i,m;
						for(i=0,m=FrameIndex*4;i<PAGE_SIZE;i++,m++)
						{
							vbuffer[i]=mem_sim->main_memory[m];
						}			//rewrite into swap
						int fds=mem_sim->swapfile_fd;
						if(write(fds,vbuffer,PAGE_SIZE)<PAGE_SIZE)
						{
							perror("write error!");
							return -1;
						}
						mem_sim->page_table[FrameIndex].P=1;
						mem_sim->page_table[FrameIndex].V =0;
						begin_index=FrameIndex*4;
						for(m=begin_index,i=0;i<4;i++,m++)
						{
							mem_sim->main_memory[m]=buffer[i];
						}
						insertInArray(array,fram,page);
						mem_sim->page_table[page].frame=fram;
						mem_sim->page_table[page].V=1;
						mem_sim->page_table[page].P=0;	
					}				
				}
				else
				{
					perror("Bss/data<=0");
					return -1;
				}
			}
		}
		else //P=0 in exe file
		{
			int fd=mem_sim->program_fd;
			lseek(fd,FrameIndex*4,SEEK_SET);
			char buffer[PAGE_SIZE];
			if(read(fd,buffer,PAGE_SIZE)!=PAGE_SIZE)
			{
				perror("read error!");
				return -1;
			}
			int begin_index=0;
			if(FrameIndex<FrameLastIndex)//memory is not full
			{
				begin_index=FrameIndex*4;
				int i,m;
				for(i=0,m=begin_index;i<PAGE_SIZE;i++,m++)
				{
					mem_sim->main_memory[m]=buffer[i];
				}
				insertInArray(array, FrameIndex ,page );
				mem_sim->page_table[page].frame=FrameIndex;
				mem_sim->page_table[page].V=1;
				mem_sim->page_table[page].P=0;
			}
			else//if the memory is full
			{
				deleteInArray(array);
				int frame=FrameIndex; 
				char vbuffer[PAGE_SIZE];
				int i,m;
				for(i=0,m=FrameIndex*4;i<PAGE_SIZE;i++,m++)
				{
					vbuffer[i]=mem_sim->main_memory[m];
				}				//rewrite into swap
				//printf("go to swap\n");
				int fds=mem_sim->swapfile_fd;
				if(write(fds,vbuffer,PAGE_SIZE)!=PAGE_SIZE)
				{
					perror("write error!");
					return -1;
				}
				mem_sim->page_table[FrameIndex].P=1;
				mem_sim->page_table[FrameIndex].V =0;
				begin_index=FrameIndex*4;
				for(m=begin_index,i=0;i<4;i++,m++)
				{
					mem_sim->main_memory[m]=buffer[i];
				}
				insertInArray(array,frame,page);
				mem_sim->page_table[page].frame=frame;
				mem_sim->page_table[page].V=1;
				mem_sim->page_table[page].P=0;	
			}
		}
		int phsical_address=((mem_sim->page_table[page].frame*PAGE_SIZE)+offset);
		return mem_sim->main_memory[phsical_address];
	}
}
/************************************************	STORE	***********************************************************************/
void store(struct sim_database * mem_sim,int address,char value)
{
	if(address<0||address>=(NUM_OF_PAGES*PAGE_SIZE))
	{
		perror("invalid address!");
		return ;
	}
	int page=(address/PAGE_SIZE);
	int offset=(address%PAGE_SIZE);
	if(mem_sim->page_table[page].V==1)
	{
		int phsical_address=((mem_sim->page_table[page].frame*PAGE_SIZE)+offset);
		mem_sim->main_memory[phsical_address]=value;
		mem_sim->page_table[page].D=1;
	}
	else
	{
		if(mem_sim->page_table[page].P==1)// go to check D swap / heap
		{
			if(mem_sim->page_table[page].D==1)//swap file
			{
				int fd=mem_sim->swapfile_fd;
				lseek(fd,FrameIndex*4,SEEK_SET);
				char buffer[PAGE_SIZE];//read the page into buffer
				if(read(fd,buffer,PAGE_SIZE)!=PAGE_SIZE)
				{
					perror("read error!");
					return ;
				}
				int begin_index=0;//write the page to ram
				if(FrameIndex<FrameLastIndex)//memory is not full
				{
					begin_index=FrameIndex*4;
					int i,m;
					for(i=0,m=begin_index;i<PAGE_SIZE;i++,m++)
					{
						mem_sim->main_memory[m]=buffer[i];
					}
					int frame=FrameIndex; 
					insertInArray(array,frame,page);
					mem_sim->page_table[page].frame=frame;
					mem_sim->page_table[page].V=1;
					mem_sim->page_table[page].P=0;
				}
				else//if the memory is full
				{
					deleteInArray(array);
					int frame=FrameIndex; 
					char vbuffer[PAGE_SIZE];
					int i,m;
					for(i=0,m=FrameIndex*4;i<PAGE_SIZE;i++,m++)
					{
						vbuffer[i]=mem_sim->main_memory[m];
					}					//rewrite into swap
					lseek(fd,FrameIndex*4,SEEK_SET);
					if(write(fd,vbuffer,PAGE_SIZE)<PAGE_SIZE)
					{
						perror("write error!");
						return ;
					}
					mem_sim->page_table[FrameIndex].P=1;
					mem_sim->page_table[FrameIndex].V =0;
					begin_index=FrameIndex*4;
					for(m=begin_index,i=0;i<4;i++,m++)
					{
						mem_sim->main_memory[m]=buffer[i];
					}
					insertInArray(array,frame,page);
					mem_sim->page_table[page].frame=frame;
					mem_sim->page_table[page].V=1;
					mem_sim->page_table[page].P=0;	
				}
			}
			else//D=0
			{
				if(codeSize>0)//exe file
				{
					int fd=mem_sim->program_fd;
					lseek(fd,FrameIndex*4,SEEK_SET);
					char buffer[PAGE_SIZE];
					if(read(fd,buffer,PAGE_SIZE)!=PAGE_SIZE)
					{
						perror("read error!");
						return ;
					}
					int begin_index=0;
					if(FrameIndex<FrameLastIndex)//memory is not full
					{
						begin_index=FrameIndex;
						int i,m;
						for(i=0,m=begin_index;i<PAGE_SIZE;i++,m++)
						{
							mem_sim->main_memory[m]=buffer[i];
						}
						insertInArray(array,FrameIndex,page);
						mem_sim->page_table[page].frame=FrameIndex;
						mem_sim->page_table[page].V=1;
						mem_sim->page_table[page].P=0;
					}
					else//if the memory is full
					{
						deleteInArray(array);
						int fram=FrameIndex; 
						char vbuffer[PAGE_SIZE];
						int i,m;
						for(i=0,m=FrameIndex*4;i<PAGE_SIZE;i++,m++)
						{
							vbuffer[i]=mem_sim->main_memory[m];
						}						//rewrite into swap
						int fds=mem_sim->swapfile_fd;
						if(write(fds,vbuffer,PAGE_SIZE)<PAGE_SIZE)
						{
							perror("write error!");
							return ;
						}
						mem_sim->page_table[FrameIndex].P=1;
						mem_sim->page_table[FrameIndex].V =0;
						begin_index=FrameIndex;
						for(m=begin_index,i=0;i<4;i++,m++)
						{
							mem_sim->main_memory[m]=buffer[i];
						}
						insertInArray(array,fram,page);
						mem_sim->page_table[page].frame=fram;
						mem_sim->page_table[page].V=1;
						mem_sim->page_table[page].P=0;	
					}
					int phsical_address=((mem_sim->page_table[page].frame*PAGE_SIZE)+offset);
					mem_sim->main_memory[phsical_address]=value;
					mem_sim->page_table[page].D=1;
				}
				else
				{
					//malloc
					char*iin=(char*)malloc(PAGE_SIZE*sizeof(char));
					
				
					
					
					
					
					
					
					
				}
			}
			int phsical_address=((mem_sim->page_table[page].frame*PAGE_SIZE)+offset);
			mem_sim->main_memory[phsical_address]=value;
			mem_sim->page_table[page].D=1;
		}
		else //P=0 in exe file
		{
			int fd=mem_sim->program_fd;
			char buffer[PAGE_SIZE];
			lseek(fd,FrameIndex*4,SEEK_SET);
			if(read(fd,buffer,PAGE_SIZE)!=PAGE_SIZE)
			{
				perror("read error!");
				return ;
			}
			int begin_index=0;
			if(FrameIndex<FrameLastIndex)//memory is not full
			{
				begin_index=FrameIndex;
				int i,m;
				for(i=0,m=begin_index;i<PAGE_SIZE;i++,m++)
				{
					mem_sim->main_memory[m]=buffer[i];
				}
				int fram=FrameIndex; 
				insertInArray(array,fram,page);
				mem_sim->page_table[page].frame=fram;
				mem_sim->page_table[page].V=1;
				mem_sim->page_table[page].P=0;
			}
			else//if the memory is full
			{
				deleteInArray(array);
				int frame=FrameIndex; 
				char vbuffer[PAGE_SIZE];
				int i,m;
				for(i=0,m=FrameIndex*4;i<PAGE_SIZE;i++,m++)
				{
					vbuffer[i]=mem_sim->main_memory[m];
				}				//rewrite into swap
				int fds=mem_sim->swapfile_fd;
				if(write(fds,vbuffer,PAGE_SIZE)<PAGE_SIZE)
				{
					perror("write error!");
					return ;
				}
				mem_sim->page_table[FrameIndex].P=1;
				mem_sim->page_table[FrameIndex].V=0;
				begin_index=FrameIndex*4;
				for(m=begin_index,i=0;i<4;i++,m++)
				{
					mem_sim->main_memory[m]=buffer[i];
				}
				insertInArray(array,frame,page);
				mem_sim->page_table[page].frame=frame;
				mem_sim->page_table[page].V=1;
				mem_sim->page_table[page].P=0;	
			}
			int phsical_address=((mem_sim->page_table[page].frame*PAGE_SIZE)+offset);
			mem_sim->main_memory[phsical_address]=value;
			mem_sim->page_table[page].D=1;
		}
	}	
}
/************************************************	PRINT	***********************************************************************/
void print_memory(struct sim_database* mem_sim)
{
	int i;
	printf("\n Physical memory\n");
	for(i=0;i<MEMORY_SIZE;i++)
	{
		printf("[%c]\n",mem_sim->main_memory[i]);
	}
}
void print_swap(struct sim_database* mem_sim)
{
	char str[PAGE_SIZE];
	int i;
	printf("\n Swap memory\n");
	lseek(mem_sim->swapfile_fd,0,SEEK_SET); // go to the start of the file
	while(read(mem_sim->swapfile_fd,str,PAGE_SIZE)==PAGE_SIZE)
	{
		for(i=0;i< PAGE_SIZE;i++) 
		{
			printf("[%c]\t", str[i]);
		}
		printf("\n");
	}
}
void print_page_table(struct sim_database* mem_sim) 
{
	int i;
	printf("\n page table \n");
	printf("Valid\t Dirty\t Permission \t Frame\n");
	for(i=0;i<NUM_OF_PAGES;i++) 
	{
		printf("[%d] \t [%d] \t [%d]    \t   [%d]\n", mem_sim->page_table[i].V,mem_sim->page_table[i].D,mem_sim->page_table[i].P, mem_sim->page_table[i].frame);
	}	
}
/************************************************	CLEAR	***********************************************************************/
void clear_system(struct sim_database * mem_sim)
{
	close(mem_sim->program_fd);
	close(mem_sim->swapfile_fd);
	free(mem_sim->page_table);
	free(mem_sim);
}