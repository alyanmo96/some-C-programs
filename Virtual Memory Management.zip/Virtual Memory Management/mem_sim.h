#ifndef MEM_SIM_H
#define MEM_SIM_H
#pragma once
#define _CRT_SECURE_NO_WARNINGS
#define PAGE_SIZE 5
#define NUM_OF_PAGES 25
#define MEMORY_SIZE 20


typedef struct page_descriptor
{
	unsigned int V;
	unsigned int frame;
	unsigned int P;
	unsigned int D;
}page_descriptor;
struct sim_database
{
	page_descriptor page_table[NUM_OF_PAGES];;
	int swapfile_fd;
	int program_fd;
	char main_memory[MEMORY_SIZE];
	int text_size;
	int data_bss_size;
	int heap_stack_size;
};
struct sim_database* init_system(char exe_file_name[],char swap_file_name[],int text_size,int data_bss_size,int heap_stack_size);
char load (struct sim_database * mem_sim,int address);
void store(struct sim_database * mem_sim,int adress,char value);
void insertInArray(int array[],int frame ,int page);
void deleteInArray(int array[]);
void print_memory(struct sim_database * mem_sim);
void print_swap(struct sim_database * mem_sim);
void print_page_table(struct sim_database * mem_sim);
void clear_system(struct sim_database * mem_sim);
#endif