#include<stdio.h>
#include <errno.h>
#include <string.h>
#include <assert.h>
#include <stdlib.h>
#include "mem_sim.h"   

int main() {


    char val;
    struct sim_database * mem_sim = init_system("exec_file", "swap_file", 25, 50, 50);

    val = load(mem_sim, 64);
    val = load(mem_sim, 66);
    val = load(mem_sim, 2);
    store(mem_sim, 98, 'X');
    val = load(mem_sim, 16);
    val = load(mem_sim, 70);
    store(mem_sim, 32, 'Y');
    store(mem_sim, 15, 'Z');
    val = load(mem_sim, 23);
	printf("val: %c\n", val ) ;

    print_page_table(mem_sim);
    print_memory(mem_sim);
    print_swap(mem_sim);
    clear_system(mem_sim);

    return (EXIT_SUCCESS);

}




