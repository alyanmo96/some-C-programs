//208505826



			{			mem_sim.c			}
			
			
			

first i start with static variable , for use it in all methods that's i use.

insertInArray   &&  deleteInArray  ;  these methods i use it to help me to know which frame is .
insertInArray : to add a new frame .
deleteInArray : if the frame array is full so i need to delete which frame , i delete the frame by fifo.

sim_database * init_system :
check if there already executable file or not , if not ---> error
check if there already swap file or not , if not ---> create one
make the main memory contain the zero value at the beging
the valid is zero , the permission 1 or zero , the dirty is zero , and the frame is equal to -1.

load  && store:
use the load method to load a char , and store method to store a new char .
this going to do after know from where to load or where we need to store .
so we need to go after some steps :
a- check the valid if yes---> physical address 
else or b-
need to check the permission and if it's was equal to one check the dirty , and after that we know if it's in 
the executable file or in the swap file , then we need to chech if the memory is full or not , if it's full 
write into the swap file , else --> physical address.

the output :
the main memory, the page table and the swap memory.‬‬