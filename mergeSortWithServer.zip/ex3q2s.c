#include <stdio.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <netinet/in.h> 
#include <arpa/inet.h>
#include <netdb.h>  
#include <stdlib.h> 
#include <string.h> 
#include <unistd.h> 
#define SIZE 1024

void error(char *msg) 
{      
	perror(msg);      
	exit(0); 
}
int merge(int arr[],int l,int m,int h)
{
  int arr1[100],arr2[100];  // Two temporary arrays to
  int n1,n2,i,j,k;
  n1=m-l+1;
  n2=h-m;

  for(i=0;i<n1;i++)
    arr1[i]=arr[l+i];
  for(j=0;j<n2;j++)
    arr2[j]=arr[m+j+1];

  arr1[i]=9999;  // To mark the end of each temporary array
  arr2[j]=9999;

  i=0;j=0;
  for(k=l;k<=h;k++)  //process of combining two sorted arrays
  {
    if(arr1[i]<=arr2[j])
      arr[k]=arr1[i++];
    else
      arr[k]=arr2[j++];
  }
  return 0;
}
int merge_sort(int arr[],int low,int high)
{
  int mid;
  if(low<high)
  {
    mid=(low+high)/2;
   // Divide and Conquer
    merge_sort(arr,low,mid);
    merge_sort(arr,mid+1,high);
   // Combine
    merge(arr,low,mid,high);
  }
  return 0;
}
int main(int argc, char *argv[]) 
{  
	
	int sockfd, newsockfd;     
	struct sockaddr_in serv_addr , cli_addr ; 
	socklen_t clilen; 
	int n, AllLength,i,Degree,j=0;
	FILE *f=fopen(argv[1],"r");
	fscanf(f,"%d,",&AllLength);
	printf("Amount of numbers that sort : %d\n",AllLength);
	fscanf(f,"%d,",&Degree);
	printf("Degree of parallelism : %d\n",Degree);
	int part=(AllLength/Degree);
	int buffer[part],rbuf[part]; 
	int arr[AllLength];
	for(i=0;i<AllLength;i++)
	{
		fscanf(f,"%d,",&arr[i]);
	}
	printf("before Sorted the array:   ");  // print sorted array
	for(i=0;i<AllLength;i++)
	{
		 if(i<(AllLength-1))
		  {
			  printf("%d , ",arr[i]);
		  }
		  else
		  {
			  printf("%d \n ",arr[i]);
		  }
	}
	if (argc < 2) 
	{          
		fprintf(stderr,"ERROR, no port provided\n");          
		exit(1);
	}
	sockfd = socket(AF_INET,SOCK_STREAM,0); 
	if (sockfd < 0)  
		error("ERROR opening socket"); 

	serv_addr.sin_family = AF_INET;  
	serv_addr.sin_addr.s_addr = INADDR_ANY; 
	serv_addr.sin_port = htons(atoi(argv[2]));////////////////////////////////////////////////////1
	if (bind(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0)                 
		error("ERROR on binding"); 	
	int k,index1=0,index2=0,y=0,h=0;j=0;
	
	listen(sockfd,Degree);
	while(j<Degree)
	{
		j++; 
		newsockfd = accept(sockfd, (struct sockaddr *) &cli_addr, &clilen); 
		// getting the IP of the client.
		char cli_ip[SIZE] ;
        inet_ntop(AF_INET , &cli_addr.sin_addr, cli_ip, SIZE ) ; 
        printf("Got request from %s\n",    cli_ip ) ;
		printf("sending '%d' numbers to socket %d \n",part,newsockfd);
		if(h==0)
		{
			h++;
			y=newsockfd;
		}
		if (newsockfd < 0)                 
			perror("ERROR on accept");
		for(k=0;k<part;k++)
		{
			buffer[k]=arr[index1];
			index1++;
		}
		if( write(newsockfd, buffer, sizeof(buffer))<0)
		   {
			   printf("<0  \n");
			   exit(-1);
		   }
		if(read(newsockfd, rbuf, sizeof(rbuf))<0)
		   {
			   printf("<0  \n");
			   exit(-1);
		   }
		for(k=0;k<part;k++)
		{
			arr[index2]=rbuf[k];
			index2++;
		}
	}
	i=0,j=0,n=0;
	int get=0;
	while(i<Degree)
	{
		i++;
		printf("reading from socket %d\n",y);y++;
		for(j=0;j<part;j++)
		{
			if(get<part-1)
			{
			  printf("%d , ",arr[n]);
			}
			else
			{
			  printf("%d \n ",arr[n]);
				get=-1;
			}
			n++;
			get++;
		}
	}
	merge_sort(arr,0,AllLength-1);
	printf("after Sorted the array:\n");
	for(i=0;i<AllLength;i++)
	  {
		 if(i<(AllLength-1))
		  {
			  printf("%d , ",arr[i]);
		  }
		  else
		  {
			  printf("%d \n ",arr[i]);
		  }
	  }
	close(newsockfd); 
	close(sockfd); 
	return 0;
}