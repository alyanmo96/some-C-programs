#include <stdio.h> 
#include <sys/types.h> 
#include <sys/socket.h> 
#include <netinet/in.h> 
#include <netdb.h>  
#include <stdlib.h> 
#include <string.h> 
#include <unistd.h> 



void error(char *msg) 
{      
	perror(msg);      
	exit(0); 
}
int merge(int arr[],int l,int m,int h)
{
  int arr1[100],arr2[100];  // Two temporary arrays to
  int n1,n2,i,j,k;
  n1=m-l+1;
  n2=h-m;
  for(i=0;i<n1;i++)
    arr1[i]=arr[l+i];
  for(j=0;j<n2;j++)
    arr2[j]=arr[m+j+1];
  arr1[i]=9999;  // To mark the end of each temporary array
  arr2[j]=9999;
  i=0;j=0;
  for(k=l;k<=h;k++)  //process of combining two sorted arrays
  {
    if(arr1[i]<=arr2[j])
      arr[k]=arr1[i++];
    else
      arr[k]=arr2[j++];
  }
  return 0;
}
int merge_sort(int arr[],int low,int high)
{
  int mid;
  if(low<high)
  {
    mid=(low+high)/2;
    merge_sort(arr,low,mid);
    merge_sort(arr,mid+1,high);
    merge(arr,low,mid,high);
  }
  return 0;
}
int main(int argc, char *argv[]) 
{  
	int sockfd, n,num,rc;     
	struct sockaddr_in serv_addr;     
	struct hostent *server; 
	int leng;
	int AllLength,Degree;
	FILE *f=fopen("input.txt","r");
	fscanf(f,"%d,",&AllLength);
	fscanf(f,"%d,",&Degree);
	leng=(AllLength/Degree);
	int buffer[leng];
	int  arr[leng];
	if (argc < 3) 
	{        
		fprintf(stderr,"usage %s hostname port\n", argv[0]);        
		exit(0); 
	} 
	sockfd = socket(AF_INET, SOCK_STREAM, 0); 
	if (sockfd < 0)         
		error("ERROR opening socket"); 
	server = gethostbyname(argv[1]);//////////////////2 
	if (server == NULL)
	{         
		fprintf(stderr,"ERROR, no such host\n");         
		exit(0); 
	}     
	serv_addr.sin_family = AF_INET;  
	bcopy((char *)server->h_addr, (char *)  &serv_addr.sin_addr.s_addr, server->h_length);    
	serv_addr.sin_port = htons(atoi(argv[2])); 
	if (connect(sockfd,(const struct sockaddr*)&serv_addr,sizeof(serv_addr)) < 0)                     
		error("ERROR connecting");
	rc = read(sockfd, buffer, sizeof(buffer)) ;
	int i;
	printf("Recived array :  ");
	for(i=0;i<leng;i++)
	{
		arr[i]=buffer[i];
		if(i<(leng-1))
		{
			printf("{%d}, ",arr[i]);
		}
		else
		{
			printf("{%d}\n ",arr[i]);
		}
	}
	merge_sort(arr,0,leng-1);
	printf("sending array :  ");
	for(i=0;i<leng;i++)
	{
		if(i<(leng-1))
		{
			printf("{%d}, ",arr[i]);
		}
		else
		{
			printf("{%d}\n ",arr[i]);
		}
	}
	for(i=0;i<leng;i++)
	{
		buffer[i]=arr[i];
	}
	rc = write(sockfd, buffer, sizeof(buffer)) ;
	close(sockfd); 
	return 0;
}	