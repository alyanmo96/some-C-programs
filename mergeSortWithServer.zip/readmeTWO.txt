start with the server
/// merge sort //////////
i take an array and sort it , how
by compare the first with last if the first bigger change places 
else compare the first with the one that before the last ... and 
continue by the same thing 



main()
create the socket and read from the file
and create an array called arr by the length that already write in the file
give the array the values
print the array before the sort

continue the process of creating the socket

loop (while)
wait for any client 
send part of the array to the first client
read the part after sort it in the client , and rewrite it sorted in the server
cointinue this until there a clients that every client need to sort a small group from the main array.
write what i get from the client . 
sort all the samll groups.
close the socket.


/////////////////////////////////////////////////////////////////////////////


the client 

////////////////////////////////////////////////////////////////////////////////
/// merge sort //////////
i take an array and sort it , how
by compare the first with last if the first bigger change places 
else compare the first with the one that before the last ... and 
continue by the same thing 

main()
create the socket and read from the file
and create an array called arr by the length that already write in the file.
print what get from the server
sort the values that the client get it from the server
print the values after sorted
send it again to the server
close the socket


