#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>
#include<sys/wait.h>
#include<sys/types.h>
#include <fcntl.h>
#include<sys/ipc.h>
#include<sys/shm.h>


int merge(int arr[],int l,int m,int h)
{
  int arr1[100],arr2[100];  // Two temporary arrays to
  int n1,n2,i,j,k;
  n1=m-l+1;
  n2=h-m;
  for(i=0;i<n1;i++)
    arr1[i]=arr[l+i];
  for(j=0;j<n2;j++)
    arr2[j]=arr[m+j+1];
  arr1[i]=9999;  // To mark the end of each temporary array
  arr2[j]=9999;
  i=0;j=0;
  for(k=l;k<=h;k++)  //process of combining two sorted arrays
  {
    if(arr1[i]<=arr2[j])
      arr[k]=arr1[i++];
    else
      arr[k]=arr2[j++];
  }
  return 0;
}
int merge_sort(int arr[],int low,int high)
{
  int mid;
  if(low<high)
  {
    mid=(low+high)/2;
    merge_sort(arr,low,mid);
    merge_sort(arr,mid+1,high);
    merge(arr,low,mid,high);
  }
  return 0;
}
int main(int argc,char *argv[])
{
  int AllLength, i, Degree, j=0;
	key_t key;
	int shm_id;
	int *ptr;
 	 FILE *f = fopen(argv[1], "r");
	fscanf(f, "%d", &AllLength);
	printf("Amount of numbers that sort : %d\n", AllLength);
	fscanf(f, "%d", &Degree);
	printf("Degree of parallelism : %d\n",Degree);
	key = ftok("/tmp", 'y');
	//create shm and retrun shm id
	if ((shm_id = shmget(key, 1000, IPC_CREAT | IPC_EXCL | 0600))==-1) 
  {
		perror("failed to get memory.....");
		exit(1);
	}
	if ((ptr = (int *)shmat(shm_id, NULL, 0)) < 0) 
  {
		perror("failed to attach memory.....");
		exit(1);
	}
	for (i = 0; i < AllLength; i++)
  {
		  fscanf(f, "%d,", &ptr[i]);
	}
	printf("before Sorted the array: ");  // print sorted array
	for (i = 0; i < AllLength; i++)
	{
		if (i < (AllLength - 1))
    {
			printf("%d , ", ptr[i]);
    }
		else
    {
			printf("%d \n ", ptr[i]);
    }
	}
	int start=0,end=(AllLength/Degree),k=0,next=(AllLength/Degree);j=0;int s=0;  
	while (j < Degree)
	{
    j++;s++;
		pid_t pid= fork();
		if (pid== 0)
		{
			printf("create a process %d\n", getpid());
			merge_sort(ptr, start, end - 1);  // sort one group of the array
			exit(0);
		}
		else
    {
			wait(NULL);
    }
    if(s==2)
    {
      s=0;
		  merge_sort(ptr, k, end - 1);  // sort the both group the each one is already sorted
		  k = end;
		  start = end; 
      end += next;
    }
    else
    {
      start = end;
      end += next;
    }
    if(end>AllLength)
      end=AllLength;
	}
  merge_sort(ptr, 0, AllLength-1);
	printf("after Sorted the array:  ");  // print sorted array
	for (i = 0; i < AllLength; i++)
	{
		if (i < (AllLength - 1))
    {
			printf("%d , ", ptr[i]);
    }
		else
    {
			printf("%d \n ", ptr[i]);
    }
	}
	shmdt(ptr); //delete pointer
  shmctl(shm_id, IPC_RMID, NULL);
	return 0;
}