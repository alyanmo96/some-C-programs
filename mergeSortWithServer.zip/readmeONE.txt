read me for EXQ1


the program start from the main method

AllLength is the first number in the input text in our example is equal to 16 .
Degree is the second number in the input text  in our example is equal to 4.

int *ptr; is my array (the pointer of the shared memory)
FILE *f = fopen("input.txt", "r"); the file that i want to read from ,iread what write there

i create the shared memory and start to use it
i enter the the numbers to the array(to the shared memory)
print the array before sort it

in the loop( while )
divid the array for two sides left and right
and divde to get the index where i want to start by use fork {the son}
start with left side send the first group on the left side to merge method to sort it , then back and sort the other group on the left side , then sort the two groups togther , then the same thongs for the right side .

after these things i get a small sorted groups , but the array by it self still not sorted for example
{9,10,11,12,1,2,3,4}the left side is sorted from 9-12 and the right 1-4
is also sorted , but the right side is smaller than 9 and smaller than (10,11,12)
so it still need to sort it.
i send all the small groups to sort and return the array sorted.
after all this i print the array
and delete the pointer of the shared memory.
/// merge sort //////////
i take an array and sort it , how
by compare the first with last if the first bigger change places 
else compare the first with the one that before the last ... and 
continue by the same thing 
