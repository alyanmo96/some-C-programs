 מוחמד עלייאן
 
 in the matrix.cpp
 
 Matrix::Matrix(int rows, int cols, string matType);
 the constractor take the value of rows and cols after check that the input are posetive number
 and make an array by the number of these values,it's also check that rows and cols isnot negative number
 ,and make all elements equal to zero
 
 
 void Matrix::setElement(int i, int j, double data);
 it's chak that i & j are legal value that's mean i<rows and j< cols
 then check the type of matType
 then check the type of the matrix and insert the value
 
 
 double Matrix::getElement(int i, int j);
 it's chak that i & j are legal value that's mean i<rows and j< cols
 then return the value
 
 
 void Matrix::add(Matrix& other, Matrix& result);
 first it's check that the two matrix are equal by rows and cols then
 it's add the matrix that we already have to a new matrix called other and put the answer in matrix called result
 
 
 void Matrix::rowShift(const int shiftSize);
 it's make shift of rows up or down ,and check if the change effect the type of the matrix
 //i used a new array to save the orginal array if the shift is illegal
 first it's check the number of rows,then the value of shiftSize,if the shiftSize is posetive or negative number
 i used a help array to save the last row in the posetive shiftSize and the first row in the negative shiftSize
 
 
 void Matrix::colShift(const int shiftSize)--> like rowShift
 //i used a new array to save the orginal array if the shift is illegal
  it's make shift of left or right ,and check if the change effect the type of the matrix
  
  
  void Matrix::print();
  to print the matrix , and btween two value in the same row print ',' and print another row in other line
  
  
  bool Matrix::checkToeplitz(int i, int j);
  method that i use to help me in isA method...this method check the toeplizt matrix
  
  bool Matrix::isA(string matType);
  check the type of the matrix first by check the matType 
  
  
  Matrix::~Matrix();
  to distructor the matrix