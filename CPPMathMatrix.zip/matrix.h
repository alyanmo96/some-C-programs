#ifndef MATRIX_H
#define MATRIX_H
#pragma once
#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include <stdlib.h>
#include<string>
using namespace std;

class Matrix {
	double **array;
	int rows, cols;
	string matType;
public:
	Matrix(int rows, int cols, string matType);
	void setElement(int i, int j, double data);
	double getElement(int i, int j);
	void add(Matrix& other, Matrix& result);
	friend istream & operator >> (istream &input, Matrix &result);///i make change here
	void rowShift(const int shiftSize);
	void colShift(const int shiftSize);
	void print();
	bool Matrix::checkToeplitz(int i, int j);
	bool isA(string matType);
	~Matrix();
};
istream & operator >> (istream &input, Matrix &result)
{
	input >> result.rows >> result.cols;
	return input;
}
#endif