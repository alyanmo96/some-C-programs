#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<string>
#include <stdlib.h>
#include"matrix.h"
using namespace std;

int r, c, i, j;
int otherRows, otherCols;
int main()
{
	string type;
	double data;
	///////////////////////these cin for the constructor//////////////////////////////////////
	cout << "please write the matType that you want for the orginal array (this)" << endl;
	cin >> type;
	/////////////////////////////////////////////////////////////////////////////////////////////////////
	cout << "please enter the number of rows for the orginal array (this)" << endl;
	cin >> r;
	/////////////////////////////////////////////////////////////////////////////////////////////////////
	cout << "please enter the number of cols for the orginal array (this)" << endl;
	cin >> c;
	////////////////////////////the constructor/////////////////////////////////////
	Matrix(r, c, type);
	////////////////////////////////these cin for the setLimit method///////////////////////////////////////////////
	cout << "please enter the number row that you want to enter elemnt in" << endl;
	cin >> i;
	cout << "please enter the number col that you want to enter elemnt in" << endl;
	cin >> j;
	cout << "please enter the data" << endl;
	cin >> data;
	//////////////////////////////////////////////////////////////////////////////////////////////////////
	Matrix m = Matrix(r, c, type);
	m.setElement(i, j, data);
	
	int counter = 1;
	while (counter<(r*c))
	{
		cout << "please enter the number row that you want to enter elemnt in" << endl;
		cin >> i;
		cout << "please enter the number col that you want to enter elemnt in" << endl;
		cin >> j;
		cout << "please enter the data" << endl;
		cin >> data;
		m.setElement(i, j, data);
		counter++;
	}
	
	cout << "please enter the number of row to return the element form the orginal array (this)" << endl;
	cin >> i;
	cout << "please enter the number of col to return the element form the orginal array (this)" << endl;
	cin >> j;
	m.getElement(i, j);
	
	
	///////////////////////these cin for the other array/////////////////////////////////////////
	cout << "please write the matType that you want for the other array" << endl;
	cin >> type;
	/////////////////////////////////////////////////////////////////////////////////////////////////////
	cout << "please enter the number of rows the other array" << endl;
	cin >> otherRows;
	/////////////////////////////////////////////////////////////////////////////////////////////////////
	cout << "please enter the number of cols the other array" << endl;
	cin >> otherCols;
	cout << "please enter the number row for the other array that you want to enter elemnt in" << endl;
	cin >> i;
	cout << "please enter the number col for the other array that you want to enter elemnt in" << endl;
	cin >> j;
	cout << "please enter the data for the other array" << endl;
	cin >> data;
	Matrix other= Matrix(otherRows, otherCols, type);
	other.setElement(i, j, data);
	counter = 1;
	while (counter<(otherRows*otherCols))
	{
		cout << "please enter the number row for the other array that you want to enter elemnt in" << endl;
		cin >> i;
		cout << "please enter the number col for the other array that you want to enter elemnt in" << endl;
		cin >> j;
		cout << "please enter the data for the other array" << endl;
		cin >> data;
		other.setElement(i, j, data);
		counter++;
	}
	Matrix result = Matrix(r, c, type);
	m.add(other, result);
	
	m.rowShift(2);
	m.colShift(-1);
	m.print();
	m.isA(type);
	m.~Matrix();
}
Matrix::Matrix(int rows, int cols, string matType)
{
	if (rows <=0 || cols <=0) 
	{
		cout << "NA" << endl;
		exit(1);
	}
	else
	{
		this->rows = rows;
		this->cols = cols;
		this->matType = matType;
		this->array = new double*[rows];
		for (int q = 0; q <rows; q++)
		{
			array[q] = new double[cols];
		}
		for (int k = 0; k <rows; k++)
		{
			for (int l = 0; l <cols; l++)
			{
				array[k][l] = 0;
			}
		}
	}
}
void Matrix::setElement(int i, int j, double data)
{
	if (i>=rows || j>=cols)
	{
		cout << "NA" << endl;
	}
	if (matType.compare("Arrowhead") == 0)
	{
		if (data != 0)
		{
			if (((i != 0 && j != 0 )&& i != j))
			{
				cout << "NA it's Arrowhead matrix" << endl;
			}
			else
			{
				array[i][j] = data;
			}
		}
	}
	if (matType.compare("Toeplitz") == 0)
	{
		if (data != 0)
		{
			if ((i != r - 1 && j != 0) || (i != 0 && j != c - 1))
			{
				array[i][j] = data;
			}
			else
			{
				cout << "NA it's Toeplitz matrix" << endl;
			}
		}
	}
	if (matType.compare("any") == 0)
	{
		array[i][j] = data;
	}
}
double Matrix::getElement(int i, int j)
{
	if (i>=rows || j>=cols)
	{
		cout << "NA" << endl;
		exit(1);
	}
	for (int k = 0; k < rows; k++)
	{
		for (int l = 0; l < cols; l++)
		{
			if ((i == k) && (j == l))
			{
				return array[k][l];
			}
		}
	}
}
void Matrix::add(Matrix& other, Matrix& result)
{
	if (other.rows != this->rows || other.cols != this->rows || other.matType.compare(this->matType)!=0)
	{
		cout << "NA" << endl;
	}
	else
	{
		for (int i = 0; i < this->rows; i++)
		{
			for (int j = 0; j < this->cols; j++)
			{
				result.array[i][j] = this->array[i][j] + other.array[i][j];
			}
		}
	}
}
bool Matrix::checkToeplitz(int i, int j)
{
	int x, y;
	x = array[i][j];
	while (i<r&&j<c)
	{
		y = array[i][j];
		if (y != x)
		{
			return false;
		}
		i++;
		j++;
	}
	return true;
}
bool Matrix::isA(string matType)
{
	if (matType.compare("Arrowhead") == 0)
	{
		for (int i = 0; i < r; i++)
		{
			for (int j = 0; j < c; j++)
			{
				if (j == 0 || i == 0 || j == i)
				{
					continue;
				}
				else
				{
					if (array[i][j] != 0)
					{
						return false;
					}
				}
			}
		}
	}
	if (matType.compare("Toeplitz") == 0)
	{
		for (int i = 0; i < r; i++)
		{
			for (int j = 0; j < c; j++)
			{
				if ((i != r - 1 && j != 0) || (i != 0 && j != c - 1))
				{
					continue;
				}
				else
				{
					if (checkToeplitz(i, j) == false)
					{
						return false;
					}
				}
			}
		}
	}
	return true;
}
void Matrix::rowShift(const int shiftSize)
{
	if (r <= 1)
	{
		cout << " there is just one row " << endl;
		exit(1);
	}//i used a new array to save the orginal array if the shift is illegal
	double **saveOrginalArray = new double*[rows];
	for (int q = 0; q <rows; q++)
	{
		saveOrginalArray[q] = new double[cols];
	}
	for (int i = 0; i < this->rows; i++)
	{
		for (int j = 0; j < this->cols; j++)
		{
			saveOrginalArray[i][j] = array[i][j];
		}
	}
	if (shiftSize >= 1)
	{
		int count = 0, x = r - 1, y = r - 2;
		double *helpArray = new double[c];
		while (count<shiftSize)
		{
			x = r - 1; y = r - 2;
			for (int i = 0; i < c; i++)
			{
				helpArray[i] = array[r - 1][i];
			}
			for (int i = 0; i < c; i++)
			{
				array[x][i] = array[y][i];
			}
			while (y>0)
			{
				x = x - 1;
				y = y - 1;
				for (int i = 0; i < c; i++)
				{
					array[x][i] = array[y][i];
				}
			}
			for (int i = 0; i < c; i++)
			{
				array[0][i] = helpArray[i];
			}
			count++;
		}
		if (isA(matType) == false)
		{
			for (int i = 0; i < this->rows; i++)
			{
				for (int j = 0; j < this->cols; j++)
				{
					array[i][j]=saveOrginalArray[i][j];
				}
			}
		}
	}
	if (shiftSize < 0)
	{
		int count = 0, x = 0, y = 1;
		double *helpArray = new double[c];
		while (count>shiftSize)
		{
			x = 0; y =1;
			for (int i = 0; i < c; i++)
			{
				helpArray[i] = array[0][i];
			}
			for (int i = 0; i < c; i++)
			{
				array[x][i] = array[y][i];
			}
			while (y<r-1)
			{
				x = x + 1;
				y = y + 1;
				for (int i = 0; i < c; i++)
				{
					array[x][i] = array[y][i];
				}
			}
			for (int i = 0; i < c; i++)
			{
				array[r-1][i] = helpArray[i];
			}
			count--;
		}
		if (isA(matType) == false)
		{
			for (int i = 0; i < this->rows; i++)
			{
				for (int j = 0; j < this->cols; j++)
				{
					array[i][j] = saveOrginalArray[i][j];
				}
			}
		}
	}
}
void Matrix::colShift(const int shiftSize)
{
	if (c <= 1)
	{
		cout << " there is just one colum " << endl;
		exit(1);
	}
	//i used a new array to save the orginal array if the shift is illegal
	double **saveOrginalArray = new double*[rows];
	for (int q = 0; q <rows; q++)
	{
		saveOrginalArray[q] = new double[cols];
	}
	for (int i = 0; i < this->rows; i++)
	{
		for (int j = 0; j < this->cols; j++)
		{
			saveOrginalArray[i][j] = array[i][j];
		}
	}
	if (shiftSize >= 1)
	{
		int count = 0, x = c - 1, y = c - 2;
		double *helpArray = new double[r];
		while (count<shiftSize)
		{
			x = c - 1; y = c - 2;
			for (int i = 0; i < r; i++)
			{
				helpArray[i] = array[i][c - 1];
			}
			for (int i = 0; i < r; i++)
			{
				array[i][x] = array[i][y];
			}
			while (y>0)
			{
				x = x - 1;
				y = y - 1;
				for (int i = 0; i < r; i++)
				{
					array[i][x] = array[i][y];
				}
			}
			for (int i = 0; i < r; i++)
			{
				array[i][0] = helpArray[i];
			}
			count++;
		}
		if (isA(matType) == false)
		{
			for (int i = 0; i < this->rows; i++)
			{
				for (int j = 0; j < this->cols; j++)
				{
					array[i][j] = saveOrginalArray[i][j];
				}
			}
		}
	}
	if (shiftSize < 0)
	{
		int count = 0, x = 0, y = 1;
		double *helpArray = new double[r];
		while (count>shiftSize)
		{
			x = 0; y = 1;
			for (int i = 0; i < r; i++)
			{
				helpArray[i] = array[i][0];
			}
			for (int i = 0; i < r; i++)
			{
				array[i][x] = array[i][y];
			}
			while (y<c - 1)
			{
				x = x + 1;
				y = y + 1;
				for (int i = 0; i < r; i++)
				{
					array[i][x] = array[i][y];
				}
			}
			for (int i = 0; i < y; i++)
			{
				array[i][c-1] = helpArray[i];
			}
			count--;
		}
		if (isA(matType) == false)
		{
			for (int i = 0; i < this->rows; i++)
			{
				for (int j = 0; j < this->cols; j++)
				{
					array[i][j] = saveOrginalArray[i][j];
				}
			}
		}
	}
}
void Matrix::print()
{
	for (int i = 0; i < r; i++)
	{
		for (int j = 0; j < c; j++)
		{
			if (j == 0)
			{
				cout << array[i][j] ;
			}
			else
			{
				cout << "," << array[i][j] ;
			}
		}
		cout << endl;
	}
}
Matrix::~Matrix()
{
	for (int i = 0; i < r; i++)
	{
		delete[] this->array;
	}
	delete[] this->array;
}