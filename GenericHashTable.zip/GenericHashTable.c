#include<stdio.h>
#include <string.h>
#include <limits.h>
#include <stdlib.h>
#include"GenericHashTable.h"


static int round=0;
Table* createTable(int size, int dType, int listLength)
{
	if (size <=0 || (dType != 0 && dType != 1)|| listLength <= 0)
	{
		return NULL;
	}
	Table *hashTable;
	if((hashTable = (Table*)malloc(sizeof(Table))) == NULL)
	{
		printf("PROBLEM IN	MEMORY\n");
		return NULL;
	}
    if(!hashTable)
    {
        printf("! Table\n");
        return NULL;
    }
	if((hashTable->arr = (Object**)malloc(sizeof(Object*)*size)) == NULL)
	{
		printf("PROBLEM IN	MEMORY\n");
		return NULL;
	}
	hashTable->m = size;
	hashTable->enterType = dType;
	hashTable->t = listLength;
	hashTable->d = 1;
	int i;
	for (i = 0; i < size; i++)
	{
		hashTable->arr[i] = NULL;
	}
	return hashTable;
}
int add(Table* table, void* data)
{
	if(table->enterType == 0)
	{
		table->arrIndex = intHashFun((int*)data, table->m);
	}
	else
	{
		table->arrIndex = strHashFun((char*)data, table->m);
	}
	Object *O;
	O = table->arr[table->arrIndex];
	int numOfNodeIndex = 0;
    if(O == NULL)
    {
        table->arr[table->arrIndex] = createObject(data);
		return table->arrIndex;
    }
    else
    {
        while(O != NULL && numOfNodeIndex < (table->t))
	    {
		    numOfNodeIndex++;
		    O = O->next;
	    }  
    }
    O = table->arr[table->arrIndex];
	if(numOfNodeIndex < (table->t))
	{
        while(O->next != NULL )
	    {
		    O = O->next;
	    } 
        O->next = createObject(data);
		return table->arrIndex;
	}
	else
	{
		CreateNewTable(table, O, data, table->arrIndex);
		return table->arrIndex;
	}
	return -1;
}
int removeObj(Table* table, void* data)
{
    Object * removeObj;
    Object * temp;
    removeObj = search(table,data);
    if(removeObj==NULL)
    {
        freeObject(removeObj, table->enterType);
        return -1;
    }
    int i,indexOfData;
	for(i = 0; i<table->m; i++)
	{
        removeObj=table->arr[i];        
        while(removeObj != NULL)
		{
			if (removeObj->data == data)
			{
		        indexOfData = i;
			}
		    removeObj = removeObj->next;   
    	}
    }
    temp=table->arr[indexOfData];
    if(temp!=NULL && isEqual(table->enterType, temp->data, data)==0)
    {
        table->arr[indexOfData]=temp->next;
        freeObject(temp, table->enterType);
        return indexOfData;
    }
    while(temp!=NULL && isEqual(table->enterType, temp->data, data)!=0)
    { 
        temp = temp->next;
    } 
    removeObj=table->arr[indexOfData];    
    while(removeObj != NULL && removeObj->next->data != temp->data)
	{
		removeObj = removeObj->next;   
    }
    removeObj->next=temp->next;
    freeObject(temp, table->enterType);
    freeObject(removeObj, table->enterType); 
    return indexOfData;
}
Object* search(Table* table, void* data)
{
	Object *searchPointer;
	int i;
	for(i = 0; i< table->m; i++)
	{
        searchPointer = table->arr[i];
		if(searchPointer != NULL)
		{
			while(searchPointer != NULL)
			{
				if(searchPointer->data == data)
				{
					return searchPointer;
				}
				searchPointer = searchPointer->next;
			}
		}
	}
    freeObject(searchPointer, table->enterType);
	return NULL;
}
void printTable(Table* table)
{
	int i;
    Object *oPrint;
	for(i = 0; i < table->m; i++)
	{
        oPrint = table->arr[i];
		if(oPrint == NULL)
		{
			printf("[%d]", i);
		}
		else
		{
			while(oPrint != NULL)
			{
				if (table->enterType == 0)
				{
					if (round == 0)
					{
                        int f1=(*(int*)oPrint->data);
						printf("[%d] %d-->", i,f1);
						round++;
					}
					else
					{
                        int f2=(*(int*)oPrint->data);
						printf(" %d-->", f2);
					}
				}
				else
				{
					if (round == 0)
					{ 
						printf("[%d] ", i);
                        int j;
                        char *copyString = (char *)malloc(strlen((char*)(oPrint->data)) + 1);
					    strcpy(copyString, (char*)(oPrint->data));
                        int len=strlen(copyString);
                        for(j=0;j<len;j++)
                        {
                           printf("%c",copyString[j]);
                        }
                        printf("-->");
						round++;
                        free(copyString);
					}
					else
					{
                        int j;
                        char *copyString = (char *)malloc(strlen((char*)(oPrint->data)) + 1);
					    strcpy(copyString, (char*)(oPrint->data));
                        int lenn=strlen(copyString);
                        for(j=0;j<lenn;j++)
                        {
                           printf("%c",copyString[j]);
                        }
                        printf("-->");
                        free(copyString);
					}
				}
				oPrint = oPrint->next;
			}
            round = 0;
		}
		printf("\n");
        freeObject(oPrint, table->enterType);
	}
}
Table* CreateNewTable(Table* table, Object* obj, void* data, int newIndex)
{
    Table *newTable;
	if((newTable = (Table*)malloc(sizeof(Table))) == NULL)
	{
		printf("PROBLEM IN	MEMORY\n");
        free(newTable);
		return NULL;
	}
    if(!newTable)
    {
        printf("! Table\n");
        return NULL;
    }
	if((newTable->arr = (Object**)malloc(sizeof(Object*)*table->m * 2)) == NULL)
	{
		printf("PROBLEM IN	MEMORY\n");
        free(newTable->arr);
		return NULL;
	}
	newTable->m = (table->m) * 2;
	newTable->t = table->t;
	newTable->enterType = table->enterType;
	newTable->d = (table->d) + 1;
	int i;
	for (i = 0; i < table->m * 2; i++)
	{
		newTable->arr[i] = NULL;
	}
	Object *newObj;
    Object *oldObj;
	if ((newObj = (Object*)malloc(sizeof(Object))) == NULL)
	{
		printf("PROBLEM IN	MEMORY\n");
        free(newObj);
		return NULL;
	}
	for( i= 0; i<table->m; i++)
	{
        oldObj = table->arr[i];
		if(table->arr[i]!= NULL)
		{
			newObj = newTable->arr[i* 2];
			newTable->arr[i* 2] = createObject(oldObj->data);
			oldObj = oldObj->next;
			while(oldObj != NULL)
			{
                newObj = newTable->arr[i* 2];
				newObj->next = createObject(oldObj->data);
				oldObj = oldObj->next;
                newObj = newObj->next;
			}
		}
	}
    int j;
    Object *pOld;
    for(j=0;j<table->m;j++)
    {
        pOld=table->arr[j];
        if(table->arr[j]!=NULL)
        {
            while(pOld!=NULL)
            {   
                removeObj(table, pOld->data);
                pOld=pOld->next;
            }
        }
    }
    table->arr=(Object**)realloc(table->arr,sizeof(Object*)*((table->m)*2));
    if(!table)
    {
        printf("! Table\n");
        return NULL;
    }
    for(i=0;i<table->m*2;i++)
    {
       table->arr[i]=NULL;
    }printf("before\n");printTable(table);printf("after \n");
    table->m*=2;
    table->d++;
    for( i= 0; i<table->m; i++)
	{
        oldObj = newTable->arr[i];
		if(newTable->arr[i]!= NULL)
		{
			newObj = newTable->arr[i];
			table->arr[i] = createObject(oldObj->data);
			oldObj = oldObj->next;
			while(oldObj != NULL)
			{
                newObj = table->arr[i];
				newObj->next = createObject(oldObj->data);
				oldObj = oldObj->next;
                newObj = newObj->next;
			}
		}
	}
    table->arr[newIndex*2+1] = createObject(data);
    freeTable(newTable);
//printf("##############1##################################\n");
//printTable(table);
//printf("@@@@@@@@@@@@@2@@@@@@@@\n");
return table;
}
Object * createObject(void* data)
{
	Object *Ob;
	if((Ob = (Object*)malloc(sizeof(Object))) == NULL)
	{
		printf("PROBLEM IN	MEMORY\n");
		return NULL;
	}
	Ob->data = data;
	Ob->next = NULL;
	return Ob;
}
void freeTable(Table* table)
{
	Object *O;
	int i,nodeRound=0;
	for (i = 0; i < table->m; i++)
	{
        O = table->arr[i];
		if (O != NULL)
		{
			while ( O != NULL && nodeRound < table->t)
			{
                O = O->next;
                nodeRound++;
			}
		}
	}	
	for (i = 0; i < table->m; i++)
	{
        if(	table->arr[i] != NULL)
        {   
            O = table->arr[i];
            while(O!=NULL)
            {
                removeObj(table, O->data);
                O = O->next;
            }
        }
	}
	free(table->arr);
	free(table);
}
void freeObject(Object* obj, int type)
{
    if(type==0  && obj!=NULL)
    {
        free(obj); 
    }  
    if(type==1  && obj!=NULL)
    {
        char * freeWord=(char*)obj->data;        
        free(freeWord); 
    }
    if(type!=0 && type!=1)
    {
        printf("TYPE IS INVALED\n");
    }       
}
int isEqual(int type, void* data1, void* data2)
{
	if(type==0 && ((int)data1==(int)data2))
	{
		return 0;
	}
	if(type==1)
	{
        char *copyString1=(char *)malloc(strlen((char*)(data1))+1);
		strcpy(copyString1, (char*)(data1));
		char *copyString2=(char *)malloc(strlen((char*)(data2))+1);
		strcpy(copyString2, (char*)(data2));
        int stringLength=strlen(copyString1);
        int i;
        for(i=0;i<stringLength;i++)
        {
            if(copyString1[i]!=copyString2[i])
            {
               free(copyString1);
               free(copyString2);
               copyString1=NULL;
               copyString2=NULL;
               return -1;
            }
        }
        free(copyString1);
        free(copyString2);
        copyString1=NULL;
        copyString2=NULL;
    	return 0;
	}
	return -1;
}
int intHashFun(int* key, int origSize)
{
    return(*(int*)key % origSize);
}
int strHashFun(char* key, int origSize)
{
	int sumOfAsciiValue=0, i;
	for(i=0;key[i]!='\0'; i++)
	{
		sumOfAsciiValue += (int)key[i];
	}
	return(sumOfAsciiValue % origSize);
}
