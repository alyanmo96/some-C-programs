#include<stdlib.h>
#include<string.h>
#include<stdio.h>
#include "GenericHashTable.h"


int main()
{
    Table *m;
    m=createTable(4,0,2);
    int i;
    int *a=190;int *b=10;int *o=38;
    int *c=17;int *s=190;int *u=22;
    i=add(m,a);
    //printf("i=%d\n",i);
    i=add(m,b);
    i=add(m,c);

printTable(m);
printf("##############################################################\n");
    i=add(m,o);i=add(m,u);i=add(m,s);
    //printf("i=%d\n",i);
   // printTable(m);
//printf("##############################################################\n");
i=add(m,(void*)22);
//Object * t;
//t=search(m,(void*) 10);
//printf("the object data is %d\n",(int)t->data);
    //removeObj(m, (void* )10);
//printTable(m);
/*
int eq=isEqual(0, a ,b);
printf("eq=%d\n",eq);

int eq=isEqual(0, a ,s);
printf("eq=%d\n",eq);
*/
    return 0;
}
