#ifndef _SMATRIX
#define _SMATRIX
#include <iostream> 
using namespace std;

class MNode {
public:
	double data;
	int indexI, indexJ;
	MNode* nextRow, *nextCol;
	MNode(double data, int i, int j);
};

class SMatrix {
private:
	MNode**rowHead,**colHead; 
	int rowSize,colSize;
	int elemNum;
	string matType;
	void setValue(int, int, double);
	void removeElement(int, int);
	void insertNode(MNode*);
	bool IsExist(int, int);
public:
	SMatrix(int rows, int cols, string matType);
	SMatrix(const SMatrix &other);
	void setElement(int i, int j, double data);
	double getElement(int i, int j);
	void setP(int i, int j, double data);
	void rowShift(int shiftSize);
	void colShift(int shiftSize);
	SMatrix& operator = (const SMatrix& other);
	SMatrix operator +(SMatrix& other);
	bool checkToeplitz();
	bool isA(string matType);
	int sizeInBytes();
	void printColumnsIndexes();
	void printRowsIndexes();
	~SMatrix();
	friend ostream& operator<<(ostream& os, SMatrix& mat);
};
#endif
