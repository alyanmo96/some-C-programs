#include <iostream> 
#include "SMatrix.h"
using namespace std;

MNode::MNode(double data, int i, int j)
{
	this->indexI = i;
	this->indexJ = j;
	this->data = data;
	this->nextRow = NULL;
	this->nextCol = NULL;
}
SMatrix::SMatrix(int rows, int cols , string matType)
{
	if (rows<0||cols<0||((matType.compare("Arrowhead")!=0)&&(matType.compare("any")!=0)&&(matType.compare("Toeplitz")!=0)))
	{
		cout << "NA" << endl; return;
	}
	this->rowSize = rows;	this->colSize = cols;	this->matType = matType;	this->elemNum = 0;
	this->rowHead = new MNode*[rows];	this->colHead = new MNode*[cols];
	if (!rowHead)
	{
		cout <<  "allocation error" << endl;		exit(1);
	}
	if (!colHead)
	{
		cout << "allocation error" << endl;		exit(1);
	}
	for (int i = 0; i < this->rowSize; i++)
		this->rowHead[i] = NULL;
	for (int j = 0; j < this->colSize; j++)
		this->colHead[j] = NULL;
}
void SMatrix::removeElement(int i, int j)
{
	MNode *prev = NULL; 	MNode *colPtr = colHead[j];  MNode *rowPtr = rowHead[i];       

	if (colHead[j]->indexI == i)             // if element is the first in column
		colHead[j] = colHead[j]->nextCol;
	else                                       // if element is not the first in column
	{
		while (colPtr->indexI != i)           // find prev element on the column
		{
			prev = colPtr;
			colPtr = colPtr->nextCol;
		}
		prev->nextCol = colPtr->nextCol;     // connect the prev with the next
	}
	if (rowHead[i]->indexJ == j)             // if element is the first in row
	{
		rowPtr = rowHead[i];
		rowHead[i] = rowHead[i]->nextRow;
	}
	else                                      // if element is not the first in row
	{
		while (rowPtr->indexJ != j)          // find prev element on the row
		{
			prev = rowPtr;
			rowPtr = rowPtr->nextRow;
		}
		prev->nextRow = rowPtr->nextRow;    // connect the prev with the next
	}
	delete rowPtr;                            // delete the element only once
}
void SMatrix::setValue(int i, int j, double data)
{
	MNode *p = this->rowHead[i];
	while (p->indexJ != j)
	{
		p = p->nextRow;
	}
	p->data = data;
}
bool SMatrix::IsExist(int i, int j)
{
	MNode *p = rowHead[i];
	if (p == NULL)
	{
		return false;
	}
	while (p && p->indexJ < j)
	{
		p = p->nextRow;
	}
	if (p && p->indexJ == j)
	{
		return true;
	}
	return false;
}
void SMatrix::setP(int i, int j, double data)//private nmethod to check the elements and the limit of the matrix
{
	bool check = IsExist(i, j);
	if (data == 0 && check == false)
	{
		return;
	}
	if (data == 0 && check == true)
	{
		this->elemNum--;
		removeElement(i, j);
	}
	if (data != 0 && check == true)
	{
		setValue(i, j, data);
	}
	if (data != 0 && check == false)
	{
		MNode *m = new MNode(data, i, j);
		this->elemNum++;
		insertNode(m);
	}
}
void SMatrix::insertNode(MNode* n)
{
	MNode* p = rowHead[n->indexI];  // the i row
	if (p != NULL)                    // there are elements in i row
	{
		if (p->indexJ > n->indexJ) // need to insert n at start, before existing elements
		{
			n->nextRow = p;
			rowHead[n->indexI] = n;
		}
		else                          // need to inserst in the middle of the list or at end
		{
			while (p->nextRow && p->nextRow->indexJ < n->indexJ)
				p = p->nextRow;
			n->nextRow = p->nextRow;
			p->nextRow = n;
		}
	}
	else                              // row is empty
		rowHead[n->indexI] = n;

	p = colHead[n->indexJ];         // the j column
	if (p != NULL)                    // there are elements in j col
	{
		if (p->indexI > n->indexI)  // need to insert n at start, before existing elements
		{
			n->nextCol = p;
			colHead[n->indexJ] = n;
		}
		else                          // need to inserst in the middle of the list or at end
		{
			while (p->nextCol && p->nextCol->indexI < n->indexI)
				p = p->nextCol;
			n->nextCol = p->nextCol;
			p->nextCol = n;
		}
	}
	else                            // column is empty
		colHead[n->indexJ] = n;
}
void SMatrix::setElement(int i, int j, double data)
{
	if (i<0 || i >= rowSize || j<0 || j >= colSize) 
	{
		cout << "setElement out of range"<<endl;		return;
	}
	else
	{
		bool found = IsExist(i, j);
		if (data == 0 && found == true)
		{
			elemNum--;			removeElement(i, j);
		}
		if (data == 0 && found == false)
			return;
		if (data != 0 && found == true)
		{
			if (matType.compare("Arrowhead") == 0)
			{
				if ((i != 0 && j != 0 && i != j))
					cout << "NA" << endl;
				else
					setValue(i, j, data);
			}
			if (matType.compare("Toeplitz") == 0)
			{
				if ((i == rowSize - 1 && j == 0) || (i == 0 && j == colSize - 1))
					setValue(i, j, data);
				else
					cout << "NA" << endl;
			}
			if (matType.compare("any") == 0)
				setValue(i, j, data);
		}
		if (data != 0 && found == false)
		{
			if (matType.compare("Arrowhead") == 0)
			{
				if ((i != 0 && j != 0 && i != j))
					cout << "NA" << endl;
				else
				{
					MNode *n = new MNode(data, i, j); 	this->elemNum++;	insertNode(n);
				}
			}
			if (matType.compare("Toeplitz") == 0)
			{
				if ((i == rowSize - 1 && j == 0) || (i == 0 && j == colSize - 1))
				{
					MNode *n = new MNode(data, i, j);		this->elemNum++;	insertNode(n);
				}
				else
					cout << "NA" << endl;
			}
			if (matType.compare("any") == 0)
			{
				MNode *n = new MNode(data, i, j);	this->elemNum++; insertNode(n);
			}
		}
	}
}
double SMatrix::getElement(int i, int j)
{
	double answer = 0;

	if (i >= rowSize || i < 0 || j >= colSize || j < 0)
	{
		cout << "NA" << endl;		exit(1);
	}
	else
	{
		if (IsExist(i, j) == false)
		{
			return 0;
		}
		MNode*p = rowHead[i];
		while (p->indexJ != j)
		{
			p = p->nextRow;
		}
		if (p->indexJ == j)
		{
			answer = p->data;
		}
	}
	return answer;
}
SMatrix::SMatrix(const SMatrix& other) {//copy constructor
	rowSize = other.rowSize;
	colSize = other.colSize;
	elemNum = 0;
	rowHead = new MNode*[other.rowSize];
	colHead = new MNode*[other.colSize];
	matType = other.matType;

	for (int i = 0; i < rowSize; i++)
		rowHead[i] = NULL;

	for (int i = 0; i < colSize; i++)
		colHead[i] = NULL;

	for (int i = 0; i < other.rowSize; i++)//to init th values 
	{
		MNode* p = other.rowHead[i];
		while (p)
		{
			setElement(p->indexI, p->indexJ, p->data);
			p = p->nextRow;
		}
	}
}
bool SMatrix::checkToeplitz()
{
	for (int i = 0; i < rowSize-1; i++)
	{
		MNode*p=rowHead[i];MNode*pp=rowHead[i+1];
		if (!p&&pp)
		{
			return false;
		}
		if (!pp&&p)
		{
			return false;
		}
		while (p&&pp)
		{
			if (pp->indexJ == 0)
			{
				pp = pp->nextRow;
			}
			if (pp->indexJ==(p->indexJ + 1) )
			{
				if (p->data != pp->data)
				{
					return false;
				}
			}
			p = p->nextRow;
			pp = pp->nextRow;
		}
	}
	return true;
}
bool SMatrix::isA(string matType)
{
	if ((matType.compare("any") != 0) && (matType.compare("Arrowhead") != 0) && (matType.compare("Toeplitz") != 0))
		return false;
	if (matType.compare("Arrowhead") == 0)
	{
		for (int i = 0; i < rowSize; i++)
		{
			MNode*p = rowHead[i];
			while (p)
			{
				if ((p->indexI != p->indexJ && p->indexI != 0 &&p->indexJ != 0))
					return false;
				p = p->nextRow;
			}
		}
	}
	if (matType.compare("Toeplitz") == 0)
	{
		for (int i = 0; i < rowSize; i++)
		{
			MNode*p = rowHead[i];
			while (p)
			{
				if ((p->indexI ==0 && p->indexJ == colSize-1) || (p->indexI == rowSize-1 && p->indexJ == 0))
				{
					p = p->nextRow;
					continue;
				}
				else
				{
					if (checkToeplitz() == false)
						return false;
				}
				p = p->nextRow;
			}
		}
	}
	return true;
}
SMatrix& SMatrix::operator = (const SMatrix& other)
{
	if (this->elemNum != 0)
	{
		for (int i = 0; i < this->rowSize; i++)
		{
			MNode* p = this->rowHead[i], *p2;
			while (p)
			{
				p2 = p;	p = p->nextRow;	delete p2;
			}
		}
	}
	delete[] other.colHead;
	delete[] other.rowHead;
	rowSize = other.rowSize;
	colSize = other.colSize;
	elemNum = 0;
	rowHead = new MNode*[other.rowSize];
	colHead = new MNode*[other.colSize];
	matType = other.matType;

	for (int i = 0; i < rowSize; i++)
		rowHead[i] = NULL;

	for (int i = 0; i < colSize; i++)
		colHead[i] = NULL;

	for (int i = 0; i < other.rowSize; i++)//to init th values 
	{
		MNode* p = other.rowHead[i];
		while (p)
		{
			setElement(p->indexI, p->indexJ, p->data);
			p = p->nextRow;
		}
	}
	return *this;
}
SMatrix SMatrix::operator +(SMatrix& other)
{
	if (this->rowSize != other.rowSize || this->colSize != other.colSize ||this->matType.compare(other.matType)!=0)
	{
		cout << "NA" << endl;	exit(1);
	}
	SMatrix res(rowSize, colSize, matType);
	SMatrix temp(other);
	for (int i = 0; i < rowSize; i++)
	{
		for (int j = 0; j < colSize; j++)
		{
			double sum = this->getElement(i,j)+ temp.getElement(i, j);
			res.setElement(i, j, sum);
		}
	}
	return res;
}
int SMatrix::sizeInBytes()
{
	return sizeof(SMatrix)+sizeof(MNode)*elemNum +sizeof(rowHead)*rowSize+sizeof(colHead)*colSize;
}
void SMatrix::printRowsIndexes()
{
	for (int i = 0; i < rowSize; i++)
	{
		MNode* p = rowHead[i];	cout << i << ":";
		while (p)
		{
			cout <<" (" << p->indexJ<< "," << p->data << ")->";
			p = p->nextRow;
		}
		cout << endl;
	}
}
void SMatrix::printColumnsIndexes()
{
	for (int i = 0; i < colSize; i++)
	{
		MNode* p=colHead[i];	cout << i << ":";
		while (p)
		{
			cout << " (" << p->indexI << "," << p->data << ")->" ;
			p = p->nextCol;
		}
		cout << endl;
	}
}
void SMatrix::rowShift(int shiftSize)
{
	int count = 0;
	if (shiftSize >= 1)
	{
		while (count<shiftSize)
		{
			int  x = rowSize - 1, y = rowSize - 2; count++;	MNode*p = rowHead[x], *pp = rowHead[y];	double *helpArray = new double[colSize];
			if (!p)
			{
				for (int i = 0; i < colSize; i++)
					helpArray[i] = 0;
			}
			if (p)
			{
				for (int i = 0; i < colSize; i++)
				{
					helpArray[p->indexJ] = p->data;
					if (p->nextRow != NULL)
						p = p->nextRow;
				}
			}
			while (y >= 0)
			{
				p = rowHead[x], pp = rowHead[y];
				for (int i = 0; i < colSize; i++)
				{
					if (!pp)
					{
						while (p)
						{
							removeElement(p->indexI, p->indexJ);	p = p->nextRow;
						}; i = colSize;		continue;
					}
					if (!p)
					{
						if (pp)
						{
							setElement(i, pp->indexJ + 1, pp->data);	pp = pp->nextRow;
						}	continue;
					}
					if (pp->indexJ > p->indexJ && p->nextRow == NULL)
					{
						setElement(pp->indexI, p->indexJ, pp->data);
						if (pp->nextRow != NULL)
							pp = pp->nextRow;
						if (p->nextRow != NULL)
							p = p->nextRow;
					}
					if (pp->indexJ > p->indexJ && p->nextRow != NULL)
					{
						removeElement(p->indexI, p->indexJ);
						if (p->nextRow != NULL)
							p = p->nextRow;
					}
					if (p->indexJ == pp->indexJ)
					{
						setElement(p->indexI, p->indexJ, pp->data);
						if (pp->nextRow != NULL)
							pp = pp->nextRow;
						if (p->nextRow != NULL)
							p = p->nextRow;
					}
					if (p->indexJ > pp->indexJ && pp->nextRow == NULL)
					{
						while (p)
						{
							removeElement(p->indexI, p->indexJ);		p = p->nextRow;
						}; i = colSize;
						continue;
					}
					if (p->indexJ > pp->indexJ && pp->nextRow != NULL)
					{
						setElement(p->indexI, pp->indexJ, pp->data);
						if (pp->nextRow != NULL)
							pp = pp->nextRow;
						if (p->nextRow != NULL)
							p = p->nextRow;
						if (!p)
							i = colSize;
					}
				}
				y--; x--;
			}
			p = rowHead[0];
			for (int i = 0; i < colSize; i++)
			{
				if (helpArray[i] != 0)
					setElement(0, i, helpArray[i]);
				if (helpArray[i] == 0)
				{
					removeElement(0, i);	p = p->nextRow;
				}
			}
			for (int i = 0; i < colSize; i++)
				helpArray[i] = 0;
		}
	}
	if (shiftSize <0)
	{
		while (count>shiftSize)
		{
			int  x = 0, y = 1; count--;	MNode*p = rowHead[x], *pp = rowHead[y];	double *helpArray = new double[colSize];
			if (!p)
			{
				for (int i = 0; i < colSize; i++)
					helpArray[i] = 0;
			}
			if (p)
			{
				for (int i = 0; i < colSize; i++)
				{
					helpArray[p->indexJ] = p->data;
					if (p->nextRow != NULL)
						p = p->nextRow;
				}
			}
			while (y <= rowSize-1)
			{
				p = rowHead[x], pp = rowHead[y];
				for (int i = 0; i < colSize; i++)
				{
					if (!pp)
					{
						while (p)
						{
							removeElement(p->indexI, p->indexJ);	p = p->nextRow;
						}; i = colSize;		continue;
					}
					if (!p)
					{
						if (pp)
						{
							setElement(i, pp->indexJ + 1, pp->data);	pp = pp->nextRow;
						}	continue;
					}
					if (pp->indexJ > p->indexJ && p->nextRow == NULL)
					{	
						setElement(pp->indexI, p->indexJ, pp->data);
						if (pp->nextRow != NULL)
							pp = pp->nextRow;
						if (p->nextRow != NULL)
							p = p->nextRow;
					}
					if (pp->indexJ > p->indexJ && p->nextRow != NULL)
					{ 
						removeElement(p->indexI, p->indexJ);
						if (p->nextRow != NULL)
							p = p->nextRow;
					}
					if (p->indexJ == pp->indexJ)
					{
						setElement(p->indexI, p->indexJ, pp->data);
						if (pp->nextRow != NULL)
							pp = pp->nextRow;
						if (p->nextRow != NULL)
							p = p->nextRow;
					}
					if (p->indexJ > pp->indexJ && pp->nextRow == NULL)
					{
						while (p)
						{
							removeElement(p->indexI, p->indexJ);		p = p->nextRow;
						}; i = colSize;
						continue;
					}
					if (p->indexJ > pp->indexJ && pp->nextRow != NULL)
					{
						setElement(p->indexI, pp->indexJ, pp->data);
						if (pp->nextRow != NULL)
							pp = pp->nextRow;
						if (!p)
							i = colSize;
					}
				}
				y++; x++;
			}
			p = rowHead[rowSize-1];
			for (int i = 0; i < colSize; i++)
			{
				if (helpArray[i] != 0)
					setElement(rowSize-1, i, helpArray[i]);
				if (helpArray[i] == 0)
				{
					removeElement(rowSize-1, i);	p = p->nextRow;
				}
			}
			for (int i = 0; i < colSize; i++)
				helpArray[i] = 0;
		}
	}
}
void SMatrix::colShift(int shiftSize)
{
	int count = 0;
	if (shiftSize >= 1)
	{
		while (count<shiftSize)
		{
			int  x = colSize - 1, y = colSize - 2; count++;	MNode*p = colHead[x], *pp = colHead[y];	double *helpArray = new double[rowSize];
			if (!p)
			{
				for (int i = 0; i < rowSize; i++)
					helpArray[i] = 0;
			}
			if (p)
			{
				for (int i = 0; i < rowSize; i++)
				{
					helpArray[p->indexI] = p->data;
					if (p->nextCol != NULL)
						p = p->nextCol;
				}
			}
			while (y >= 0)
			{
				p = colHead[x], pp = colHead[y];
				for (int i = 0; i < rowSize; i++)
				{
					if (!pp)
					{
						while (p)
						{
							removeElement(p->indexI, p->indexJ);	p = p->nextCol;
						}; i = rowSize;		continue;
					}
					if (!p)
					{
						if (pp)
						{
							setElement(i, pp->indexJ + 1, pp->data);	pp = pp->nextCol;
						}	continue;
					}
					if (pp->indexI > p->indexI && p->nextCol == NULL)
					{
						setElement(pp->indexI, p->indexJ, pp->data);
						if (pp->nextCol != NULL)
							pp = pp->nextCol;
						if (p->nextCol != NULL)
							p = p->nextCol;
					}
					if (pp->indexI > p->indexI && p->nextCol != NULL)
					{
						removeElement(p->indexI, p->indexJ);
						if (p->nextCol != NULL)
							p = p->nextCol;
					}
					if (p->indexI == pp->indexI)
					{
						setElement(p->indexI, p->indexJ, pp->data);
						if (pp->nextCol != NULL)
							pp = pp->nextCol;
						if (p->nextCol != NULL)
							p = p->nextCol;
					}
					if (p->indexI > pp->indexI && pp->nextCol == NULL)
					{
						while (p)
						{
							removeElement(p->indexI, p->indexJ);		p = p->nextCol;
						}; i = rowSize;
						continue;
					}
					if (p->indexI > pp->indexI && pp->nextCol != NULL)
					{
						setElement(pp->indexI, p->indexJ, pp->data);
						if (pp->nextCol != NULL)
							pp = pp->nextCol;
						if (p->nextCol != NULL)
							p = p->nextCol;
						if (!p)
							i = rowSize;
					}
				}
				y--; x--;
			}
			p = colHead[0];
			for (int i = 0; i < rowSize; i++)
			{
				if (helpArray[i] != 0)
					setElement(i, 0, helpArray[i]);
				if (helpArray[i] == 0)
				{
					removeElement(i, 0);	p = p->nextCol;
				}
			}
			for (int i = 0; i < rowSize; i++)
				helpArray[i] = 0;
		}
	}
	if (shiftSize < 0)
	{
		while (count>shiftSize)
		{
			int  x = 0, y = 1; count--;	MNode*p = colHead[x], *pp = colHead[y];	double *helpArray = new double[rowSize];
			if (!p)
			{
				for (int i = 0; i < rowSize; i++)
					helpArray[i] = 0;
			}
			if (p)
			{
				for (int i = 0; i < rowSize; i++)
				{
					helpArray[p->indexI] = p->data;
					if (p->nextCol != NULL)
						p = p->nextCol;
				}
			}
			while (y <=colSize-1)
			{
				p = colHead[x], pp = colHead[y];
				for (int i = 0; i < rowSize; i++)
				{
					if (!pp)
					{
						while (p)
						{
							removeElement(p->indexI, p->indexJ);	p = p->nextCol;
						}; i = rowSize;		continue;
					}
					if (!p)
					{
						if (pp)
						{
							setElement(i, pp->indexJ + 1, pp->data);	pp = pp->nextCol;
						}	continue;
					}
					if (pp->indexI > p->indexI && p->nextCol == NULL)
					{
						setElement(pp->indexI, p->indexJ, pp->data);
						if (pp->nextCol != NULL)
							pp = pp->nextCol;
						if (p->nextCol != NULL)
							p = p->nextCol;
					}
					if (pp->indexI > p->indexI && p->nextCol != NULL)
					{
						removeElement(p->indexI, p->indexJ);
						if (p->nextCol != NULL)
							p = p->nextCol;
					}
					if (p->indexI == pp->indexI)
					{
						setElement(p->indexI, p->indexJ, pp->data);
						if (pp->nextCol != NULL)
							pp = pp->nextCol;
						if (p->nextCol != NULL)
							p = p->nextCol;
					}
					if (p->indexI > pp->indexI && pp->nextCol == NULL)
					{
						while (p)
						{
							removeElement(p->indexI, p->indexJ);		p = p->nextCol;
						}; i = rowSize;
						continue;
					}
					if (p->indexI > pp->indexI && pp->nextCol != NULL)
					{
						setElement(pp->indexI, p->indexJ, pp->data);
						if (pp->nextCol != NULL)
							pp = pp->nextCol;
						if (p->nextCol != NULL)
							p = p->nextCol;
						if (!p)
							i = rowSize;
					}
				}y++; x++;
			}
			p = colHead[colSize-1]; 
			for (int i = 0; i < rowSize; i++)
			{
				if (helpArray[i] != 0)
					setElement(i, colSize-1, helpArray[i]);
				if (helpArray[i] == 0)
				{
						removeElement(i, colSize-1);	p = p->nextCol;
				}
			}
			for (int i = 0; i < rowSize; i++)
				helpArray[i] = 0;
		}
	}
}
SMatrix::~SMatrix()
{
	if (elemNum != 0)
	{
		for (int i = 0; i < rowSize; i++)
		{
			MNode* p = rowHead[i], *p2;
			while (p)
			{
				p2 = p;		p = p->nextRow;		delete p2;
			}
		}
	}
	delete[] colHead; delete[] rowHead;
}
void printZero(int num)
{
	for (int i = 0; i < num; i++)
	{
		if (i <= num -1)
			cout << "0,";
		else
			cout << "0";
	}
}
ostream& operator<<(std::ostream& os, SMatrix& mat)
{
	int curIndex, lastIndex;
	for (int i = 0; i < mat.rowSize; i++)
	{
		lastIndex = -1;
		MNode* p = mat.rowHead[i];
		while (p)
		{
			curIndex = p->indexJ;
			printZero(curIndex - lastIndex - 1);
			os << p->data << ",";
			lastIndex = p->indexJ;
			p = p->nextRow;
		}
		printZero(mat.colSize - lastIndex - 1);
		os << endl;
	}
	return os;
}