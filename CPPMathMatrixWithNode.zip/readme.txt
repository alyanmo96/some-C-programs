 מוחמד עלייאן
 ת.ז 208505826
 
 in the SMatrix.cpp
 
 
 SMatrix::SMatrix(int rows, int cols, string matType);
 the constractor take the value of rows and cols after check that the input are posetive number
 ,it's also check that rows and cols isnot negative number
 ,and make all elements equal to zero,and check the matType
 
 
 void SMatrix::setElement(int i, int j, double data);
 it's check that i & j are legal value that's mean i<rows and j< cols
 then check the type of matType
 then check the type of the SMatrix and insert the value
 
 
 double SMatrix::getElement(int i, int j);
 it's check that i & j are legal value that's mean i<rows and j< cols
 then return the value,by pointers
 
 
 SMatrix operator +(SMatrix& other);
 first it's check that the two SMatrix are equal by rows and cols then
 it's add the matrix that we already have to a new matrix called other and put the answer in matrix called result
 
 void setP(int i, int j, double data);
 privte method i use it to help me for rowShift or colShift
 
 
 void SMatrix::rowShift(const int shiftSize);
 i used an array to save one row the top if the shiftSize was bigger than one else to save the bottom row
 then if the shiftSize posetive each row equal to it's above row by pointers and in the end the top row equal to array values
 
 
 
 void SMatrix::colShift(const int shiftSize);
 i used an array to save one col the first if the shiftSize was bigger than one else to save the last col
 then if the shiftSize posetive each row equal to it's beside row by pointers and in the end the top col equal to array values
 
  
  
  friend ostream& operator<<(ostream& os, SMatrix& mat);
  to print the SMatrix , and btween two value in the same row print ',' and print another row in other line
  
  
	void printRowsIndexes();
	to print the SMatrix , and btween two value in the same row  print the indexJ ','  the row and print "->"
  
  void printColumnsIndexes();
	to print the SMatrix , and btween two value in the same colum  print the indexJ ','  the colum and print "->"
  
  bool SMatrix::checkToeplitz(int i, int j);
  method that i use to help me in isA method...this method check the toeplizt matrix
  
  bool SMatrix::isA(string matType);
  check the type of the matrix first by check the matType 
  
  
  SMatrix::~SMatrix();
  to distructor the Smatrix